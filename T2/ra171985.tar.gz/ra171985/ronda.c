#include "api_robot2.h"

int main() {

	return 0;
}
